import React from "react";

const Table = ({ tableData }) => {
  return (
    <table className='table table-borderless'>
      <thead
        style={{
          backgroundColor: "#90DAF6",
          color: "white",
          fontWeight: "bold",
        }}>
        <tr>
          <th scope='col'>Name</th>
          <th scope='col'>Phone</th>
          <th scope='col'>Gender</th>
        </tr>
      </thead>
      <tbody>
        {tableData.map((el) => {
          return (
            <tr>
              <td>{el.name}</td>
              <td>{el.phone}</td>
              <td>{el.gender}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};
export default Table;
